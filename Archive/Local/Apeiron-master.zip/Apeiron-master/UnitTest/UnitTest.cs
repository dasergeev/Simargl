﻿global using System.Collections;
global using Complex = System.Numerics.Complex;

using System.Resources;

[assembly: NeutralResourcesLanguage("ru")]
