﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTest.Utilities;

/// <summary>
/// Представляет счётчик.
/// </summary>
class Counter
{
    /// <summary>
    /// Поле для хранения значения.
    /// </summary>
    int _Value;

    /// <summary>
    /// Инициализирует новый экземпляр класса.
    /// </summary>
    public Counter()
    {
        //  Инициализация значения счётчика.
        _Value = 0;
    }

    /// <summary>
    /// Выполняет увеличение счётчика.
    /// </summary>
    public void Raise()
    {
        //  Увеличение значения счётчика.
        ++_Value;
    }

    /// <summary>
    /// Выполняет сброс счётчика.
    /// </summary>
    public void Reset()
    {
        //  Сброс значения счётчика.
        _Value = 0;
    }

    /// <summary>
    /// Проверяет, равено ли значение счётчика указанному значению, и создает исключение, если значения не равны.
    /// </summary>
    /// <param name="actual">
    /// Актуальное значение счётчика.
    /// </param>
    /// <exception cref="AssertFailedException">
    /// Значения не равны.
    /// </exception>
    public void AreEqual(int actual)
    {
        //  Проверка.
        Assert.AreEqual(_Value, actual);
    }

    /// <summary>
    /// Создаёт обработчика события.
    /// </summary>
    /// <typeparam name="T">
    /// Тип аргументов события.
    /// </typeparam>
    /// <returns>
    /// Обработчик события.
    /// </returns>
    public Action<object, T> CreateHandler<T>()
    {
        //  Возврат обработчика события.
        return (object sender, T e) =>
        {
            //  Увеличение счётчика события.
            Raise();
        };
    }
}
