﻿namespace UnitTest.Utilities;

/// <summary>
/// Представляет тестовое перечисление.
/// </summary>
public enum TestEnum
{
    /// <summary>
    /// Один.
    /// </summary>
    One = 1,

    /// <summary>
    /// Два.
    /// </summary>
    Two = 2,

    /// <summary>
    /// Три.
    /// </summary>
    Three = 3,
}
