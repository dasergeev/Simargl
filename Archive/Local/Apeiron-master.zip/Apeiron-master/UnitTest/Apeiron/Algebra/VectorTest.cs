﻿using Apeiron.Algebra;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using BigInteger = System.Numerics.BigInteger;
using Quaternion = System.Numerics.Quaternion;

namespace UnitTest.Apeiron.Algebra;

/// <summary>
/// Представляет тестовый класс для класса <see cref="Vector{T}"/>.
/// </summary>
[TestClass]
public class VectorTest
{
    /// <summary>
    /// Тестирует конструкторы.
    /// </summary>
    [TestMethod]
    public void TestConstructors()
    {
        //  Выполняет тестирование реализации.
        void realization<T>()
        {
            //  Тестирование конструктора по умолчанию.
            {
                //  Создание вектора.
                Vector<T> vector = new();

                //  Проверка длины вектора.
                Assert.AreEqual(vector.Length, 0);
            }

            //  Тестирование конструктора с указанием длины вектора.
            {
                //  Цикл по длине.
                for (int length = -10; length < 10; length++)
                {
                    //  Проверка длины.
                    if (length < 0)
                    {
                        //  Проверка исключения.
                        Assert.ThrowsException<ArgumentOutOfRangeException>(() => _ = new Vector<T>(length));
                    }
                    else
                    {
                        //  Создание вектора.
                        Vector<T> vector = new(length);

                        //  Проверка длины вектора.
                        Assert.AreEqual(vector.Length, length);
                    }
                }
            }
        }

        //  Тестирование реализаций.
        realization<byte>();
        realization<sbyte>();
        realization<ushort>();
        realization<short>();
        realization<uint>();
        realization<int>();
        realization<ulong>();
        realization<long>();
        realization<float>();
        realization<double>();
        realization<decimal>();
        realization<BigInteger>();
        realization<Complex>();
        realization<Quaternion>();
        realization<bool>();
        realization<char>();
        realization<DateTime>();
        realization<string>();
        realization<Vector<byte>>();
        realization<Vector<sbyte>>();
        realization<Vector<ushort>>();
        realization<Vector<short>>();
        realization<Vector<uint>>();
        realization<Vector<int>>();
        realization<Vector<ulong>>();
        realization<Vector<long>>();
        realization<Vector<float>>();
        realization<Vector<double>>();
        realization<Vector<decimal>>();
        realization<Vector<BigInteger>>();
        realization<Vector<Complex>>();
        realization<Vector<Quaternion>>();
        realization<Vector<bool>>();
        realization<Vector<char>>();
        realization<Vector<DateTime>>();
        realization<Vector<string>>();
    }
}
