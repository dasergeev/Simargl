﻿using Apeiron.Memory;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections;

namespace UnitTest.Apeiron.Memory;

/// <summary>
/// Представляет тестовый класс для класса <see cref="RawBuffer{T}"/>.
/// </summary>
[TestClass]
public class RawBufferTest
{
    /// <summary>
    /// Тестирует конструкторы.
    /// </summary>
    [TestMethod]
    public void TestConstructors()
    {
        //  Цикл по длине буфера.
        foreach (var length in new int[] { -10, -1, 0, 1, 10, 100 })
        {
            //  Проверка длины.
            if (length <= 0)
            {
                //  Конструктор должен выбросить исключение.
                Assert.ThrowsException<ArgumentOutOfRangeException>(
                    () => new RawBuffer<int>(length));
            }
            else
            {
                //  Конструктор не должен выбрасывать исключения.
                var buffer = new RawBuffer<int>(length);

                //  Проверка длины буфера.
                Assert.AreEqual(length, buffer.Length);
            }
        }
    }

    /// <summary>
    /// Тестирует индексаторы.
    /// </summary>
    [TestMethod]
    public void TestIndexers()
    {
        //  Длина буфера.
        var length = 10;

        //  Создание буфера.
        RawBuffer<int> buffer = new(length);

        //  Цикл по индексам.
        for (int i = -2 * length; i != 2 * length; ++i)
        {
            //  Запись значения.
            buffer[i] = i;

            //  Чтение значения.
            Assert.AreEqual(i, buffer[i]);

            //  Запись значения.
            buffer[(long)i] = i;

            //  Чтение значения.
            Assert.AreEqual(i, buffer[(long)i]);

            //  Запись значения.
            buffer.Write(i, i);

            //  Чтение значения.
            Assert.AreEqual(i, buffer.Read(i));
        }
    }

    /// <summary>
    /// Тестирует методы записи.
    /// </summary>
    [TestMethod]
    public void TestWrite()
    {
        //  Создание буфера.
        RawBuffer<int> buffer = new(5);

        //  Создание массива.
        var array = new int[30];

        //  Заполнение масива.
        for (int i = 0; i != 30; ++i)
        {
            array[i] = i;
        }

        //  Метод должен выбросить исключение.
        Assert.ThrowsException<ArgumentNullException>(() => buffer.Write(0, null!));

        //  Цикл по смещениям в массиве.
        for (int offset = -1; offset != 31; ++offset)
        {
            //  Цикл по количеству элементов.
            for (int count = -1; count < 31; ++count)
            {
                //  Метод должен выбросить исключение.
                Assert.ThrowsException<ArgumentNullException>(
                    () => buffer.Write(0, null!, offset, count));

                //  Проверка параметров.
                if (offset < 0 ||
                    count < 0 ||
                    offset > 30 ||
                    offset + count > 30)
                {
                    //  Метод должен выбросить исключение.
                    Assert.ThrowsException<ArgumentOutOfRangeException>(
                        () => buffer.Write(0, array, offset, count));
                }
                else
                {
                    //  Метод не должен выбрасывать исключений.
                    buffer.Write(0, array, offset, count);
                }
            }
        }

        //  Входной массив полностью умещается в буфере.
        {
            //  Цикл по смещению в массиве.
            for (int offset = 0; offset != 10; ++offset)
            {
                //  Цикл по индексу в буфере.
                for (int index = -10; index < 10; ++index)
                {
                    //  Запись в буфер.
                    buffer.Write(index, array, offset, 3);

                    //  Проверка записанных значений.
                    Assert.AreEqual(offset + 0, buffer[index + 0]);
                    Assert.AreEqual(offset + 1, buffer[index + 1]);
                    Assert.AreEqual(offset + 2, buffer[index + 2]);
                }
            }
        }

        //  Входной массив полностью не умещается в буфере.
        {
            //  Цикл по смещению в массиве.
            for (int offset = 0; offset != 10; ++offset)
            {
                //  Цикл по индексу в буфере.
                for (int index = -10; index < 10; ++index)
                {
                    //  Запись в буфер.
                    buffer.Write(index, array, offset, 10);

                    //  Проверка записанных значений.
                    Assert.AreEqual(offset + 5, buffer[index + 0]);
                    Assert.AreEqual(offset + 6, buffer[index + 1]);
                    Assert.AreEqual(offset + 7, buffer[index + 2]);
                    Assert.AreEqual(offset + 8, buffer[index + 3]);
                    Assert.AreEqual(offset + 9, buffer[index + 4]);
                }
            }
        }

        //  Запись всего массива.
        {
            //  Цикл по индексу в буфере.
            for (int index = -10; index < 10; ++index)
            {
                //  Запись в буфер.
                buffer.Write(index, array);

                //  Проверка записанных значений.
                Assert.AreEqual(25, buffer[index + 0]);
                Assert.AreEqual(26, buffer[index + 1]);
                Assert.AreEqual(27, buffer[index + 2]);
                Assert.AreEqual(28, buffer[index + 3]);
                Assert.AreEqual(29, buffer[index + 4]);
            }
        }
    }

    /// <summary>
    /// Тестирует методы чтения.
    /// </summary>
    [TestMethod]
    public void TestRead()
    {
        //  Создание буфера.
        RawBuffer<int> buffer = new(5);

        //  Заполенние буфера.
        buffer.Write(0, 0, 1, 2, 3, 4);

        //  Создание массива.
        var array = new int[30];

        //  Заполнение масива.
        for (int i = 0; i != 30; ++i)
        {
            array[i] = i;
        }

        //  Цикл по смещениям в массиве.
        for (int offset = -1; offset != 31; ++offset)
        {
            //  Цикл по количеству элементов.
            for (int count = -1; count < 31; ++count)
            {
                //  Метод должен выбросить исключение.
                Assert.ThrowsException<ArgumentNullException>(
                    () => buffer.Read(0, null!, offset, count));

                //  Проверка параметров.
                if (offset < 0 ||
                    count < 0 ||
                    offset > 30 ||
                    offset + count > 30)
                {
                    //  Метод должен выбросить исключение.
                    Assert.ThrowsException<ArgumentOutOfRangeException>(
                        () => buffer.Read(0, array, offset, count));
                }
                else
                {
                    //  Метод не должен выбрасывать исключений.
                    buffer.Read(0, array, offset, count);
                }
            }
        }

        //  Цикл по смещению в массиве.
        for (int offset = 0; offset != 10; ++offset)
        {
            //  Цикл по количеству считываемых элементов.
            for (int count = 0; count != 10; ++count)
            {
                //  Цикл по индексу в буфере.
                for (int index = -10; index < 10; ++index)
                {
                    //  Чтение из буфера.
                    buffer.Read(index, array, offset, count);

                    //  Проверка прочитанных значений.
                    for (int i = 0; i != count; ++i)
                    {
                        Assert.AreEqual(buffer[index + i], array[offset + i]);
                    }
                }
            }
        }

        //  Цикл по количеству считываемых элементов.
        for (int count = 0; count != 10; ++count)
        {
            //  Цикл по индексу в буфере.
            for (int index = -10; index < 10; ++index)
            {
                //  Чтение из буфера.
                array = buffer.Read(index, count);

                //  Проверка размера массива.
                Assert.AreEqual(count, array.Length);

                //  Проверка прочитанных значений.
                for (int i = 0; i != count; ++i)
                {
                    Assert.AreEqual(buffer[index + i], array[i]);
                }
            }
        }
    }

    /// <summary>
    /// Тестирует методы клонирования.
    /// </summary>
    [TestMethod]
    public void TestClone()
    {
        //  Массив тестовых значений.
        var values = new RawBuffer<int>[10];

        //  Инициализация тестовых значений.
        for (int i = 0; i != values.Length; ++i)
        {
            //  Создание буфера.
            RawBuffer<int> buffer = new(i + 1);

            //  Инициализация буфера.
            for (int j = 0; j != buffer.Length; ++j)
            {
                //  Установка значения.
                buffer[j] = j;
            }

            //  Установка буфера.
            values[i] = buffer;
        }

        //  Цикл по тестовым значениям.
        foreach (var value in values)
        {
            //  Копирование значения.
            var duplicate = value.Clone();

            //  Проверка содержимого.
            for (int i = 0; i != value.Length; ++i)
            {
                Assert.AreEqual(value[i], duplicate[i]);
            }

            //  Копирование через интерфейс.
            duplicate = (RawBuffer<int>)((ICloneable)value).Clone();

            //  Проверка содержимого.
            for (int i = 0; i != value.Length; ++i)
            {
                Assert.AreEqual(value[i], duplicate[i]);
            }
        }
    }

    /// <summary>
    /// Тестирует поведение коллекции.
    /// </summary>
    [TestMethod]

    public void TestCollection()
    {
        //  Тестовый буфер.
        RawBuffer<int> buffer = new(10);

        //  Инициализация тестового буфера.
        for (int i = 0; i != buffer.Length; ++i)
        {
            //  Установка значения.
            buffer[i] = i;
        }

        //  Тестирование универсального перечислителя.
        {
            //  Индекс текущего элемента.
            var index = 0;

            //  Перебор элементов коллекции.
            foreach (var value in buffer)
            {
                //  Проверка значения.
                Assert.AreEqual(buffer[index], value);

                //  Увеличение индекса текущего элемента.
                ++index;
            }
        }

        //  Тестирование перечислителя.
        {
            //  Индекс текущего элемента.
            var index = 0;

            //  Перебор элементов коллекции.
            foreach (var value in (IEnumerable)buffer)
            {
                //  Проверка значения.
                Assert.AreEqual(buffer[index], (int)value);

                //  Увеличение индекса текущего элемента.
                ++index;
            }
        }

        //  Проверка количества элементов.
        Assert.AreEqual(buffer.Length, ((IReadOnlyCollection<int>)buffer).Count);
    }
}
