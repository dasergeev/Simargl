﻿using Apeiron.Memory;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTest.Apeiron.Memory;

/// <summary>
/// Представляет тестовый класс для класса <see cref="CircularBuffer{T}"/>.
/// </summary>
[TestClass]
public class CircularBufferTest
{
    /// <summary>
    /// Тестирует конструкторы.
    /// </summary>
    [TestMethod]
    public void TestConstructors()
    {
        //  Цикл по длине буфера.
        foreach (var length in new int[] { -10, -1, 0, 1, 10, 100 })
        {
            //  Проверка длины.
            if (length <= 0)
            {
                //  Конструктор должен выбросить исключение.
                Assert.ThrowsException<ArgumentOutOfRangeException>(
                    () => new CircularBuffer<int>(length));
            }
            else
            {
                //  Конструктор не должен выбрасывать исключения.
                var buffer = new CircularBuffer<int>(length);

                //  Проверка длины буфера.
                Assert.AreEqual(length, buffer.Length);

                //  Проверка начальной позиции.
                Assert.AreEqual(0, buffer.BeginPosition);

                //  Проверка следующей за последней позиции.
                Assert.AreEqual(0, buffer.EndPosition);

                //  Проверка объекта, с помощью которого можно синхронизировать доступ к буферу.
                Assert.IsNotNull(buffer.SyncRoot);
            }
        }
    }

    /// <summary>
    /// Тестирует индексаторы.
    /// </summary>
    [TestMethod]
    public void TestIndexers()
    {
        //  Массив тестовых значений.
        int[] values = new int[20];

        //  Установка тестовых значений.
        for (int i = 0; i != values.Length; ++i)
        {
            //  Установка значения.
            values[i] = i;
        }

        //  Длина буфера.
        var length = 10;

        //  Создание буфера.
        CircularBuffer<int> buffer = new(length);

        //  Начальная позиция в буфере, полученная через обработчик события.
        long eventBeginPosition = 0;

        //  Следующая за последней позиция в буфере, полученная через обработчик события.
        long eventEndPosition = 0;

        //  Обработчик события.
        void eventHandler(object sender, CircularBufferEventArgs e)
        {
            //  Установка начальной позиции в буфере.
            eventBeginPosition = e.BeginPosition;

            //  Установка следующей за последней позиции в буфере.
            eventEndPosition = e.EndPosition;
        }

        //  Установка обработчика события.
        buffer.Changed += eventHandler;

        //  Цикл по тестовым значениям.
        foreach (var value in values)
        {
            //  Запись значения.
            buffer.Write(value);

            //  Проверка записанного значения.
            Assert.AreEqual(value, buffer[buffer.EndPosition - 1]);

            //  Проверка начальной позиции, полученной через событие.
            Assert.AreEqual(eventBeginPosition, buffer.BeginPosition);

            //  Проверка следующей за последней позиции, полученной через событие.
            Assert.AreEqual(eventEndPosition, buffer.EndPosition);

            //  Цикл по позициям.
            for (long position = buffer.BeginPosition - length;
                position != buffer.EndPosition + length;
                ++position)
            {
                //  Проверка позиции.
                if (position >= buffer.BeginPosition && position < buffer.EndPosition)
                {
                    //  Метод и индексатор не должны вызывать исключений.
                    //  Метод и индексатор должны возвращать одно и тоже значение.
                    Assert.AreEqual(buffer.Read(position), buffer[position]);
                }
                else
                {
                    //  Метод должен вызвать исключение.
                    Assert.ThrowsException<ArgumentOutOfRangeException>(
                        () => buffer.Read(position));

                    //  Индексатор должен вызвать исключение.
                    Assert.ThrowsException<ArgumentOutOfRangeException>(
                        () => buffer[position]);
                }
            }
        }
    }

    /// <summary>
    /// Тестирует методы записи.
    /// </summary>
    [TestMethod]
    public void TestWrite()
    {
        //  Создание буфера.
        CircularBuffer<int> buffer = new(5);

        //  Создание массива.
        var array = new int[30];

        //  Заполнение масива.
        for (int i = 0; i != 30; ++i)
        {
            array[i] = i;
        }

        //  Метод должен выбросить исключение.
        Assert.ThrowsException<ArgumentNullException>(() => buffer.Write(null!));

        //  Метод должен выбросить исключение.
        Assert.ThrowsException<ArgumentOutOfRangeException>(() => buffer.Write(new int[30]));

        //  Цикл по смещениям в массиве.
        for (int offset = -1; offset != 31; ++offset)
        {
            //  Цикл по количеству элементов.
            for (int count = -1; count < 31; ++count)
            {
                //  Метод должен выбросить исключение.
                Assert.ThrowsException<ArgumentNullException>(
                    () => buffer.Write(null!, offset, count));

                //  Проверка параметров.
                if (count > 5 ||
                    offset < 0 ||
                    count < 0 ||
                    offset > 30 ||
                    offset + count > 30)
                {
                    //  Метод должен выбросить исключение.
                    Assert.ThrowsException<ArgumentOutOfRangeException>(
                        () => buffer.Write(array, offset, count));
                }
                else
                {
                    //  Метод не должен выбрасывать исключений.
                    buffer.Write(array, offset, count);
                }
            }
        }

        //  Цикл по смещению в массиве.
        for (int offset = 0; offset != 10; ++offset)
        {
            //  Запись в буфер.
            buffer.Write(array, offset, 3);

            //  Проверка записанных значений.
            Assert.AreEqual(offset + 0, buffer[buffer.EndPosition - 3]);
            Assert.AreEqual(offset + 1, buffer[buffer.EndPosition - 2]);
            Assert.AreEqual(offset + 2, buffer[buffer.EndPosition - 1]);
        }
    }
}
