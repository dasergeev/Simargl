﻿using Apeiron.Memory;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTest.Apeiron.Memory;

/// <summary>
/// Представляет тестовый класс для класса <see cref="CircularBufferEventArgs"/>.
/// </summary>
[TestClass]
public class CircularBufferEventArgsTest
{
    /// <summary>
    /// Общее тестирование.
    /// </summary>
    [TestMethod]
    public void TestCommon()
    {
        //  Цикл по начальной позиции.
        for (int beginPosition = -10; beginPosition != 10; ++beginPosition)
        {
            //  Цикл по следующей за последней позиции.
            for (int endPosition = -10; endPosition != 10; ++endPosition)
            {
                //  Проверка позиций.
                if (beginPosition < 0 ||
                    endPosition < 0 ||
                    beginPosition > endPosition)
                {
                    //  Конструктор должен выбросить исключение.
                    Assert.ThrowsException<ArgumentOutOfRangeException>(
                        () => new CircularBufferEventArgs(beginPosition, endPosition));
                }
                else
                {
                    //  Создание аргументов события.
                    CircularBufferEventArgs e = new(beginPosition, endPosition);

                    //  Проверка начальной позиции.
                    Assert.AreEqual(beginPosition, e.BeginPosition);

                    //  Проверка ледующей за последней позиции.
                    Assert.AreEqual(endPosition, e.EndPosition);
                }
            }
        }
    }
}
