﻿using Apeiron.Compute.Cpu;
using Apeiron.Frames;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using UnitTest.Properties;

namespace UnitTest.Apeiron.Frames;

/// <summary>
/// Представляет тестовый класс.
/// </summary>
[TestClass]
public class FrameTest
{
    /// <summary>
    /// Тестирует метод.
    /// </summary>
    [TestMethod]
    public void CommonTest()
    {
        byte[] bytes = Resources.Vp0_0;
        using MemoryStream stream = new(bytes);
        Frame frame = new(stream);
        Assert.AreEqual(frame.Channels.Count, 10);
    }
}
