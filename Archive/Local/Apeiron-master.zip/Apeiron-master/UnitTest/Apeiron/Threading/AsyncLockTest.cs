﻿using Apeiron.Threading;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTest.Apeiron.Threading;

/// <summary>
/// Представляет тестовый класс для класса <see cref="AsyncLock"/>.
/// </summary>
[TestClass]
public class AsyncLockTest
{
    /// <summary>
    /// Общее тестирование.
    /// </summary>
    [TestMethod]
    public async Task TestCommonAsync()
    {
        // Создаём объект для ассинхронной блокировки.
        AsyncLock asyncLock = new();

        int value = 0;

        using (await asyncLock.LockAsync())
        {
            int oldValue = value;
            await Task.Delay(TimeSpan.FromMilliseconds(500));
            value = oldValue + 1;
        }

        // Разрушает объект ассинхронной блокировки.
        asyncLock.Dispose();
    }

    /// <summary>
    /// Тестирует, что блокировку не заклинивает в бесконечное ожидание впринципе, если не задан таймаут и тест успевает заверщаться за указанное время 2000 мс.
    /// </summary>
    [TestMethod, Timeout(2000)]
    public async Task AsyncLockSimpleTest()
    {
        int counter = 0;

        using var asyncLock = new AsyncLock();
        using (await asyncLock.LockAsync())
        {
            counter++;
        }
    }

    ///// <summary>
    ///// Тестирование вложенной блокировки AsyncLock. При превышении 15 сек. считаем что встал в бесконечную блокировку из которой не может выйти.
    ///// </summary>
    //[TestMethod, Timeout(15000)]
    //public async Task AsyncLockIncludeLock()
    //{
    //    int value = 0;

    //    using (var asyncLock = new AsyncLock())
    //    {
    //        using (await asyncLock.LockAsync())
    //        {
    //            using (await asyncLock.LockAsync())
    //            {
    //                int oldValue = value;
    //                await Task.Delay(TimeSpan.FromMilliseconds(300));
    //                value = oldValue + 1;
    //            }
    //            await Task.Delay(TimeSpan.FromMilliseconds(300));
    //        }
    //    }
    //}

    /// <summary>
    /// Тестирование вложенной блокировки AsyncLock с созданием нового объекта класса AsyncLock.
    /// </summary>
    [TestMethod, Timeout(15000)]
    public async Task AsyncLockIncludeLockWithNewObject()
    {
        int value = 0;

        //Создаём первый объект
        using var asyncLock = new AsyncLock();
        using (await asyncLock.LockAsync())
        {
            await Task.Delay(TimeSpan.FromMilliseconds(100));
            // Создаём второй объект.
            using var asyncLock2 = new AsyncLock();
            using (await asyncLock2.LockAsync())
            {
                int oldValue = value;
                await Task.Delay(TimeSpan.FromMilliseconds(300));
                value = oldValue + 1;
            }
        }
    }

    ///// <summary>
    ///// Тестирование AsyncLock при параллельном выполенении.
    ///// </summary>
    //[TestMethod]
    //public void TestAsyncLockParallel()
    //{
    //    int counter = 0;
    //    int counterIterator = 0;
    //    using (var asyncLock = new AsyncLock())
    //    {
    //        Parallel.For(0, 3, async i =>
    //        {
    //            using (await asyncLock.LockAsync())
    //            {
    //                counterIterator++;
    //                for (int j = 0; j < 10; j++)
    //                {
    //                    await Task.Delay(10);
    //                    counter++;
    //                    //Debug.WriteLine($"Outside {counter}, Thread {Thread.CurrentThread.ManagedThreadId}");
    //                }
    //            }
    //        });
    //    }
    //    Assert.AreEqual(3, counterIterator);
    //}

    /// <summary>
    /// Тестирует на исключение типа TimeoutException, ArgumentOutOfRangeException, OperationCanceledException.
    /// </summary>
    [TestMethod]
    public async Task TestAsyncLockException()
    {
        CancellationTokenSource cancelationTokenSource = new();
        CancellationToken cancellationToken = cancelationTokenSource.Token;

        // Создаём объект для ассинхронной блокировки.
        AsyncLock asyncLock = new();
        try
        {
            ////  Метод должен выбросить исключение TimeoutException.
            //await Assert.ThrowsExceptionAsync<TimeoutException>(async () =>
            //{
            //    using (await asyncLock.LockAsync(TimeSpan.FromMilliseconds(500)))
            //    {
            //        await Task.Delay(TimeSpan.FromMilliseconds(600));
            //    }
            //});

            //  Метод должен выбросить исключение ArgumentOutOfRangeException.
            await Assert.ThrowsExceptionAsync<ArgumentOutOfRangeException>(async () =>
            {
                await asyncLock.LockAsync(-1000);
            });

            //  Метод должен выбросить исключение OperationCanceledException.
            cancelationTokenSource.Cancel();
            await Assert.ThrowsExceptionAsync<OperationCanceledException>(async () =>
            {
                await asyncLock.LockAsync(TimeSpan.FromMilliseconds(500), cancellationToken);
            });
        }
        finally
        {
            // Разрушает объект ассинхронной блокировки.
            asyncLock.Dispose();
        }
    }

    /// <summary>
    /// Тестирует на исключения вида ObjectDisposedException.
    /// </summary>
    [TestMethod]
    public async Task TestAsyncLockException_ObjectDisposedException()
    {
        // Создаём объект для ассинхронной блокировки.
        AsyncLock asyncLock = new();
        // Разрушает объект ассинхронной блокировки.
        asyncLock.Dispose();

        //  Метод должен выбросить исключение ObjectDisposedException.
        await Assert.ThrowsExceptionAsync<ObjectDisposedException>(async () =>
        {
            await asyncLock.LockAsync(TimeSpan.FromMilliseconds(500));
        });
    }
}
