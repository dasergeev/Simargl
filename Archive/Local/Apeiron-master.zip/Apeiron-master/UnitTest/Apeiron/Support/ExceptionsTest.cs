﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using UnitTest.Utilities;

namespace UnitTest.Apeiron.Support;

/// <summary>
/// Представляет тестовый класс для класса <see cref="Exceptions"/>.
/// </summary>
[TestClass]
public class ExceptionsTest
{
    /// <summary>
    /// Тестирует метод <see cref="Exceptions.ArgumentArrayLargerMax(string)"/>.
    /// </summary>
    [TestMethod]
    public void TestArgumentArrayLargerMax()
    {
        //  Метод должен создавать исключение.
        var ex = Assert.ThrowsException<ArgumentOutOfRangeException>(
            () => throw Exceptions.ArgumentArrayLargerMax("first"));

        //  Проверка сообщения.
        StringAssert.StartsWith(ex.Message,
            "В параметре first передан массив, размер которого больше максимально допустимого.");
    }

    /// <summary>
    /// Тестирует метод <see cref="Exceptions.ArgumentArrayLessMin(string)"/>.
    /// </summary>
    [TestMethod]
    public void TestArgumentArrayLessMin()
    {
        //  Метод должен создавать исключение.
        var ex = Assert.ThrowsException<ArgumentOutOfRangeException>(
            () => throw Exceptions.ArgumentArrayLessMin("first"));

        //  Проверка сообщения.
        StringAssert.StartsWith(ex.Message,
            "В параметре first передан массив, размер которого меньше минимально допустимого.");
    }

    /// <summary>
    /// Тестирует метод <see cref="Exceptions.ArgumentNullReference(string)"/>.
    /// </summary>
    [TestMethod]
    public void TestArgumentNullReference()
    {
        //  Метод должен создавать исключение.
        var ex = Assert.ThrowsException<ArgumentNullException>(
            () => throw Exceptions.ArgumentNullReference("first"));

        //  Проверка сообщения.
        StringAssert.StartsWith(ex.Message,
            "В параметре first передана пустая ссылка.");
    }

    /// <summary>
    /// Тестирует метод <see cref="Exceptions.ArgumentNotContainedInEnumeration{T}(string)"/>.
    /// </summary>
    [TestMethod]
    public void TestArgumentNotContainedInEnumeration()
    {
        //  Метод должен создавать исключение.
        var ex = Assert.ThrowsException<ArgumentOutOfRangeException>(
            () => throw Exceptions.ArgumentNotContainedInEnumeration<TestEnum>("first"));

        //  Проверка сообщения.
        StringAssert.StartsWith(ex.Message,
            $"В параметре first передано значение, которое не содержится в перечислении {nameof(TestEnum)}.");
    }

    /// <summary>
    /// Тестирует метод <see cref="Exceptions.ArgumentEmptyArray(string)"/>.
    /// </summary>
    [TestMethod]
    public void TestArgumentEmptyArray()
    {
        //  Метод должен создавать исключение.
        var ex = Assert.ThrowsException<ArgumentOutOfRangeException>(
            () => throw Exceptions.ArgumentEmptyArray("first"));

        //  Проверка сообщения.
        StringAssert.StartsWith(ex.Message,
            "В параметре first передан пустой массив.");
    }

    /// <summary>
    /// Тестирует метод <see cref="Exceptions.ArgumentEmptyCollection(string)"/>.
    /// </summary>
    [TestMethod]
    public void TestArgumentEmptyCollection()
    {
        //  Метод должен создавать исключение.
        var ex = Assert.ThrowsException<ArgumentOutOfRangeException>(
            () => throw Exceptions.ArgumentEmptyCollection("first"));

        //  Проверка сообщения.
        StringAssert.StartsWith(ex.Message,
            "В параметре first передана пустая коллекция.");
    }

    /// <summary>
    /// Тестирует метод <see cref="Exceptions.ArgumentEmptyString(string)"/>.
    /// </summary>
    [TestMethod]
    public void TestArgumentEmptyStringn()
    {
        //  Метод должен создавать исключение.
        var ex = Assert.ThrowsException<ArgumentOutOfRangeException>(
            () => throw Exceptions.ArgumentEmptyString("first"));

        //  Проверка сообщения.
        StringAssert.StartsWith(ex.Message,
            "В параметре first передана пустая строка.");
    }

    /// <summary>
    /// Тестирует метод <see cref="Exceptions.ArgumentNegativeValue(string)"/>.
    /// </summary>
    [TestMethod]
    public void TestArgumentNegativeValue()
    {
        //  Метод должен создавать исключение.
        var ex = Assert.ThrowsException<ArgumentOutOfRangeException>(
            () => throw Exceptions.ArgumentNegativeValue("first"));

        //  Проверка сообщения.
        StringAssert.StartsWith(ex.Message,
            "В параметре first передано отрицательное значение.");
    }

    /// <summary>
    /// Тестирует метод <see cref="Exceptions.ArgumentZeroValue(string)"/>.
    /// </summary>
    [TestMethod]
    public void TestArgumentZeroValue()
    {
        //  Метод должен создавать исключение.
        var ex = Assert.ThrowsException<ArgumentOutOfRangeException>(
            () => throw Exceptions.ArgumentZeroValue("first"));

        //  Проверка сообщения.
        StringAssert.StartsWith(ex.Message,
            "В параметре first передано нулевое значение.");
    }

    /// <summary>
    /// Тестирует метод <see cref="Exceptions.ArgumentOutOfRange(string)"/>.
    /// </summary>
    [TestMethod]
    public void TestArgumentOutOfRange()
    {
        //  Метод должен создавать исключение.
        var ex = Assert.ThrowsException<ArgumentOutOfRangeException>(
            () => throw Exceptions.ArgumentOutOfRange("first"));

        //  Проверка сообщения.
        StringAssert.StartsWith(ex.Message,
            "В параметре first передано значение, которое не соответствует допустимому диапазону значений.");
    }

    /// <summary>
    /// Тестирует метод <see cref="Exceptions.OperationEnumerationChanged"/>.
    /// </summary>
    [TestMethod]
    public void TestOperationEnumerationChanged()
    {
        //  Метод должен создавать исключение.
        var ex = Assert.ThrowsException<InvalidOperationException>(
            () => throw Exceptions.OperationEnumerationChanged());

        //  Проверка сообщения.
        StringAssert.StartsWith(ex.Message,
            "После создания перечислителя семейство было изменено.");
    }

    /// <summary>
    /// Тестирует метод <see cref="Exceptions.OperationOverflow"/>.
    /// </summary>
    [TestMethod]
    public void TestOperationOverflow()
    {
        //  Метод должен создавать исключение.
        var ex = Assert.ThrowsException<OverflowException>(
            () => throw Exceptions.OperationOverflow());

        //  Проверка сообщения.
        StringAssert.StartsWith(ex.Message,
            "Операция привела к переполнению.");
    }
}
