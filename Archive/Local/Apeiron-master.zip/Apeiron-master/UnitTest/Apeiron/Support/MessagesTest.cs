﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Globalization;

namespace UnitTest.Apeiron.Support;

/// <summary>
/// Представляет тестовый класс для класса <see cref="Messages"/>.
/// </summary>
[TestClass]
public class MessagesTest
{
    /// <summary>
    /// Общее тестирование.
    /// </summary>
    [TestMethod]
    public void TestCommon()
    {
        //  Массив параметров.
        var args = new object[] { "first", "second" };

        //  Массив тестовых значений.
        var values =
            new ValueTuple<string, string, string>[]
            {
                (Messages.ArgumentArrayLargerMax,
                "В параметре {0} передан массив, размер которого больше максимально допустимого.",
                "В параметре first передан массив, размер которого больше максимально допустимого."),

                (Messages.ArgumentArrayLessMin,
                "В параметре {0} передан массив, размер которого меньше минимально допустимого.",
                "В параметре first передан массив, размер которого меньше минимально допустимого."),

                (Messages.ArgumentEmptyArray,
                "В параметре {0} передан пустой массив.",
                "В параметре first передан пустой массив."),

                (Messages.ArgumentEmptyCollection,
                "В параметре {0} передана пустая коллекция.",
                "В параметре first передана пустая коллекция."),

                (Messages.ArgumentEmptyString,
                "В параметре {0} передана пустая строка.",
                "В параметре first передана пустая строка."),

                (Messages.ArgumentNegativeValue,
                "В параметре {0} передано отрицательное значение.",
                "В параметре first передано отрицательное значение."),

                (Messages.ArgumentNotContainedInEnumeration,
                "В параметре {0} передано значение, которое не содержится в перечислении {1}.",
                "В параметре first передано значение, которое не содержится в перечислении second."),

                (Messages.ArgumentNullReference,
                "В параметре {0} передана пустая ссылка.",
                "В параметре first передана пустая ссылка."),

                (Messages.ArgumentOutOfRange,
                "В параметре {0} передано значение, которое не соответствует допустимому диапазону значений.",
                "В параметре first передано значение, которое не соответствует допустимому диапазону значений."),

                (Messages.ArgumentZeroValue,
                "В параметре {0} передано нулевое значение.",
                "В параметре first передано нулевое значение."),

                (Messages.OperationEnumerationChanged,
                "После создания перечислителя семейство было изменено.",
                "После создания перечислителя семейство было изменено."),

                (Messages.OperationOverflow,
                "Операция привела к переполнению.",
                "Операция привела к переполнению."),
            };

        //  Перебор тестовых значений.
        foreach (var value in values)
        {
            //  Проверяемое сообщение.
            var message = value.Item1;

            //  Исходная строка.
            var source = value.Item2;

            //  Целевая строка.
            var target = value.Item3;

            //  Проверка ссылки на строку.
            Assert.IsNotNull(message);

            //  Проверка значения строки.
            Assert.AreEqual(source, message);

            //  Проверка целевой строки.
            Assert.AreEqual(target, string.Format(CultureInfo.InvariantCulture, message, args));
        }
    }
}
