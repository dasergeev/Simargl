﻿//using Microsoft.VisualStudio.TestTools.UnitTesting;
//using System.Collections;
//using UnitTest.Utilities;

//namespace UnitTest.Apeiron.Support;

///// <summary>
///// Представляет тестовый класс для класса <see cref="Check"/>.
///// </summary>
//[TestClass]
//public class CheckTest
//{
//    /// <summary>
//    /// Тестирует метод проверки на передачу пустой ссылки.
//    /// </summary>
//    [TestMethod]
//    public void TestReference()
//    {
//        //  Массив тестовых значений.
//        object[] values = { null!, "object", new object() };

//        //  Перебор тестовых значений.
//        foreach (var value in values)
//        {
//            //  Проверка значения.
//            if (value is null)
//            {
//                //  Метод должен выбросить исключение.
//                Assert.ThrowsException<ArgumentNullException>(
//                    () => Check.IsNotNull(value, nameof(value)));

//                //  Метод должен выбросить исключение.
//                Assert.ThrowsException<ArgumentNullException>(
//                    () => Check.IsNotNull(value, null));
//            }
//            else
//            {
//                //  Метод должен вернуть проверяемое значение.
//                Assert.AreEqual(value, Check.IsNotNull(value, nameof(value)));

//                //  Метод должен вернуть проверяемое значение.
//                Assert.AreEqual(value, Check.IsNotNull(value, null));
//            }
//        }
//    }

//    /// <summary>
//    /// Тестирует метод проверки на принадлежность значения перечислению.
//    /// </summary>
//    [TestMethod]
//    public void TestDefined()
//    {
//        //  Массив тестовых значений.
//        var values = new TestEnum[] { 0, TestEnum.One, TestEnum.Two, TestEnum.Three, (TestEnum)5, (TestEnum)10 };

//        //  Перебор тестовых значений.
//        foreach (var value in values)
//        {
//            //  Проверка значения.
//            if (!Enum.IsDefined(typeof(TestEnum), value))
//            {
//                //  Метод должен выбросить исключение.
//                Assert.ThrowsException<ArgumentOutOfRangeException>(
//                    () => Check.IsDefined(value, nameof(value)));
//            }
//            else
//            {
//                //  Метод должен вернуть проверяемое значение.
//                Assert.AreEqual(value, Check.IsDefined(value, nameof(value)));
//            }
//        }
//    }

//    /// <summary>
//    /// Тестирует методы проверки на пустоту.
//    /// </summary>
//    [TestMethod]
//    public void TestEmpty()
//    {
//        //  Тестирование перегрузки для массивов.
//        {
//            //  Массив тестовых значений.
//            int[][] values = { null!, Array.Empty<int>(), new int[1], new int[2] };

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка ссылки.
//                if (value is null)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentNullException>(
//                        () => Check.IsNotEmpty(value, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentNullException>(
//                        () => Check.IsNotEmpty(value, null));
//                }
//                else
//                {
//                    //  Проверка количества элементов.
//                    if (value.Length == 0)
//                    {
//                        //  Метод должен выбросить исключение.
//                        Assert.ThrowsException<ArgumentOutOfRangeException>(
//                            () => Check.IsNotEmpty(value, nameof(value)));

//                        //  Метод должен выбросить исключение.
//                        Assert.ThrowsException<ArgumentOutOfRangeException>(
//                            () => Check.IsNotEmpty(value, null));
//                    }
//                    else
//                    {
//                        //  Метод должен вернуть проверяемое значение.
//                        Assert.AreEqual(value, Check.IsNotEmpty(value, nameof(value)));

//                        //  Метод должен вернуть проверяемое значение.
//                        Assert.AreEqual(value, Check.IsNotEmpty(value, null));
//                    }
//                }
//            }
//        }

//        //  Тестирование перегрузки для коллекций.
//        {
//            //  Массив тестовых значений.
//            IEnumerable [] values = { null!, Array.Empty<int>(), new int[1], new int[2] };

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка ссылки.
//                if (value is null)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentNullException>(
//                        () => Check.IsNotEmpty(value, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentNullException>(
//                        () => Check.IsNotEmpty(value, null));
//                }
//                else
//                {
//                    //  Проверка количества элементов.
//                    if (((int[])value).Length == 0)
//                    {
//                        //  Метод должен выбросить исключение.
//                        Assert.ThrowsException<ArgumentOutOfRangeException>(
//                            () => Check.IsNotEmpty(value, nameof(value)));

//                        //  Метод должен выбросить исключение.
//                        Assert.ThrowsException<ArgumentOutOfRangeException>(
//                            () => Check.IsNotEmpty(value, null));
//                    }
//                    else
//                    {
//                        //  Метод должен вернуть проверяемое значение.
//                        Assert.AreEqual(value, Check.IsNotEmpty(value, nameof(value)));

//                        //  Метод должен вернуть проверяемое значение.
//                        Assert.AreEqual(value, Check.IsNotEmpty(value, null));
//                    }
//                }
//            }
//        }

//        //  Тестирование перегрузки для строк.
//        {
//            //  Массив тестовых значений.
//            string[] values = { null!, string.Empty, "First", "Second" };

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка ссылки.
//                if (value is null)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentNullException>(
//                        () => Check.IsNotEmpty(value, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentNullException>(
//                        () => Check.IsNotEmpty(value, null));
//                }
//                else
//                {
//                    //  Проверка длины.
//                    if (value.Length == 0)
//                    {
//                        //  Метод должен выбросить исключение.
//                        Assert.ThrowsException<ArgumentOutOfRangeException>(
//                            () => Check.IsNotEmpty(value, nameof(value)));

//                        //  Метод должен выбросить исключение.
//                        Assert.ThrowsException<ArgumentOutOfRangeException>(
//                            () => Check.IsNotEmpty(value, null));
//                    }
//                    else
//                    {
//                        //  Метод должен вернуть проверяемое значение.
//                        Assert.AreEqual(value, Check.IsNotEmpty(value, nameof(value)));

//                        //  Метод должен вернуть проверяемое значение.
//                        Assert.AreEqual(value, Check.IsNotEmpty(value, null));
//                    }
//                }
//            }
//        }
//    }

//    /// <summary>
//    /// Тестирует методы проверки диапазона.
//    /// </summary>
//    [TestMethod]
//    public void TestRange()
//    {
//        //  Цикл по длине массива.
//        for (int length = 0; length != 5; ++length)
//        {
//            //  Тестовый массив.
//            var array = new int[length];

//            //  Формурует массив тестируемых действий.
//            Action[] getActions(int[] array, int offset, int count)
//            {
//                return new Action[]
//                {
//                () => Check.IsRange(array, offset, count, nameof(array), nameof(offset), nameof(count)),
//                () => Check.IsRange(array, offset, count, null, nameof(offset), nameof(count)),
//                () => Check.IsRange(array, offset, count, nameof(array), null, nameof(count)),
//                () => Check.IsRange(array, offset, count, null, null, nameof(count)),
//                () => Check.IsRange(array, offset, count, nameof(array), nameof(offset), null),
//                () => Check.IsRange(array, offset, count, null, nameof(offset), null),
//                () => Check.IsRange(array, offset, count, nameof(array), null, null),
//                () => Check.IsRange(array, offset, count, null, null, null)
//                };
//            }

//            //  Цикл по смещениям.
//            for (int offset = -1; offset != length + 1; ++offset)
//            {
//                //  Цикл по количеству элементов.
//                for (int count = -1; count < length + 1; ++count)
//                {
//                    //  Передача пустой ссылки на массив.
//                    foreach (var action in getActions(null!, offset, count))
//                    {
//                        //  Метод должен выбросить исключение.
//                        Assert.ThrowsException<ArgumentNullException>(action);
//                    }

//                    //  Проверка параметров.
//                    if (offset < 0 ||
//                        count < 0 ||
//                        offset > length ||
//                        offset + count > length)
//                    {
//                        foreach (var action in getActions(array, offset, count))
//                        {
//                            //  Метод должен выбросить исключение.
//                            Assert.ThrowsException<ArgumentOutOfRangeException>(action);
//                        }
//                    }
//                    else
//                    {
//                        foreach (var action in getActions(array, offset, count))
//                        {
//                            //  Метод не должен выбрасывать исключений.
//                            action();
//                        }
//                    }
//                }
//            }
//        }
//    }

//    /// <summary>
//    /// Тестирует методы проверки на отрицательность.
//    /// </summary>
//    [TestMethod]
//    public void TestNegative()
//    {
//        //  Тестирование перегрузки с типом sbyte.
//        {
//            //  Массив тестовых значений.
//            sbyte[] values = GenericTester<sbyte>.Values;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value < 0)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotNegative(value, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotNegative(value, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotNegative(value, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotNegative(value, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом short.
//        {
//            //  Массив тестовых значений.
//            short[] values = GenericTester<short>.Values;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value < 0)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotNegative(value, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotNegative(value, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotNegative(value, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotNegative(value, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом int.
//        {
//            //  Массив тестовых значений.
//            int[] values = GenericTester<int>.Values;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value < 0)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotNegative(value, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotNegative(value, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotNegative(value, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotNegative(value, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом long.
//        {
//            //  Массив тестовых значений.
//            long[] values = GenericTester<long>.Values;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value < 0)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotNegative(value, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotNegative(value, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotNegative(value, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotNegative(value, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом float.
//        {
//            //  Массив тестовых значений.
//            float[] values = GenericTester<float>.Values;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value < 0)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotNegative(value, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotNegative(value, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotNegative(value, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotNegative(value, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом double.
//        {
//            //  Массив тестовых значений.
//            double[] values = GenericTester<double>.Values;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value < 0)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotNegative(value, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotNegative(value, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotNegative(value, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotNegative(value, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом decimal.
//        {
//            //  Массив тестовых значений.
//            decimal[] values = GenericTester<decimal>.Values;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value < 0)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotNegative(value, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotNegative(value, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotNegative(value, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotNegative(value, null));
//                }
//            }
//        }
//    }

//    /// <summary>
//    /// Тестирует методы проверки на равенство нулю.
//    /// </summary>
//    [TestMethod]
//    public void TestZero()
//    {
//        //  Тестирование перегрузки с типом byte.
//        {
//            //  Массив тестовых значений.
//            byte[] values = GenericTester<byte>.Values;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value == 0)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotZero(value, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotZero(value, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotZero(value, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotZero(value, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом ushort.
//        {
//            //  Массив тестовых значений.
//            ushort[] values = GenericTester<ushort>.Values;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value == 0)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotZero(value, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotZero(value, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotZero(value, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotZero(value, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом uint.
//        {
//            //  Массив тестовых значений.
//            uint[] values = GenericTester<uint>.Values;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value == 0)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotZero(value, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotZero(value, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotZero(value, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotZero(value, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом ulong.
//        {
//            //  Массив тестовых значений.
//            ulong[] values = GenericTester<ulong>.Values;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value == 0)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotZero(value, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotZero(value, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotZero(value, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotZero(value, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом sbyte.
//        {
//            //  Массив тестовых значений.
//            sbyte[] values = GenericTester<sbyte>.Values;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value == 0)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotZero(value, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotZero(value, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotZero(value, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotZero(value, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом short.
//        {
//            //  Массив тестовых значений.
//            short[] values = GenericTester<short>.Values;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value == 0)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotZero(value, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotZero(value, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotZero(value, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotZero(value, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом int.
//        {
//            //  Массив тестовых значений.
//            int[] values = GenericTester<int>.Values;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value == 0)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotZero(value, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotZero(value, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotZero(value, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotZero(value, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом long.
//        {
//            //  Массив тестовых значений.
//            long[] values = GenericTester<long>.Values;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value == 0)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotZero(value, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotZero(value, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotZero(value, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotZero(value, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом float.
//        {
//            //  Массив тестовых значений.
//            float[] values = GenericTester<float>.Values;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value == 0)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotZero(value, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotZero(value, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotZero(value, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotZero(value, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом double.
//        {
//            //  Массив тестовых значений.
//            double[] values = GenericTester<double>.Values;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value == 0)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotZero(value, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotZero(value, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotZero(value, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotZero(value, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом decimal.
//        {
//            //  Массив тестовых значений.
//            decimal[] values = GenericTester<decimal>.Values;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value == 0)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotZero(value, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotZero(value, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotZero(value, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotZero(value, null));
//                }
//            }
//        }
//    }

//    /// <summary>
//    /// Тестирует методы проверки на отрицательность или равенство нулю.
//    /// </summary>
//    [TestMethod]
//    public void TestIsPositive()
//    {
//        //  Тестирование перегрузки с типом sbyte.
//        {
//            //  Массив тестовых значений.
//            sbyte[] values = GenericTester<sbyte>.Values;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value < 0 || value == 0)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsPositive(value, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsPositive(value, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsPositive(value, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsPositive(value, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом short.
//        {
//            //  Массив тестовых значений.
//            short[] values = GenericTester<short>.Values;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value < 0 || value == 0)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsPositive(value, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsPositive(value, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsPositive(value, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsPositive(value, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом int.
//        {
//            //  Массив тестовых значений.
//            int[] values = GenericTester<int>.Values;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value < 0 || value == 0)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsPositive(value, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsPositive(value, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsPositive(value, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsPositive(value, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом long.
//        {
//            //  Массив тестовых значений.
//            long[] values = GenericTester<long>.Values;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value < 0 || value == 0)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsPositive(value, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsPositive(value, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsPositive(value, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsPositive(value, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом float.
//        {
//            //  Массив тестовых значений.
//            float[] values = GenericTester<float>.Values;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value < 0 || value == 0)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsPositive(value, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsPositive(value, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsPositive(value, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsPositive(value, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом double.
//        {
//            //  Массив тестовых значений.
//            double[] values = GenericTester<double>.Values;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value < 0 || value == 0)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsPositive(value, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsPositive(value, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsPositive(value, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsPositive(value, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом decimal.
//        {
//            //  Массив тестовых значений.
//            decimal[] values = GenericTester<decimal>.Values;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value < 0 || value == 0)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsPositive(value, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsPositive(value, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsPositive(value, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsPositive(value, null));
//                }
//            }
//        }
//    }

//    /// <summary>
//    /// Тестирует методы проверки на превышение.
//    /// </summary>
//    [TestMethod]
//    public void TestIsNotLarger()
//    {
//        //  Тестирование перегрузки с типом byte.
//        {
//            //  Массив тестовых значений.
//            byte[] values = GenericTester<byte>.Values;

//            //  Максимально допустимое значение.
//            byte maxValue = 10;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value > maxValue)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotLarger(value, maxValue, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotLarger(value, maxValue, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotLarger(value, maxValue, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotLarger(value, maxValue, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом ushort.
//        {
//            //  Массив тестовых значений.
//            ushort[] values = GenericTester<ushort>.Values;

//            //  Максимально допустимое значение.
//            ushort maxValue = 10;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value > maxValue)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotLarger(value, maxValue, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotLarger(value, maxValue, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotLarger(value, maxValue, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotLarger(value, maxValue, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом uint.
//        {
//            //  Массив тестовых значений.
//            uint[] values = GenericTester<uint>.Values;

//            //  Максимально допустимое значение.
//            uint maxValue = 10;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value > maxValue)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotLarger(value, maxValue, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotLarger(value, maxValue, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotLarger(value, maxValue, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotLarger(value, maxValue, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом ulong.
//        {
//            //  Массив тестовых значений.
//            ulong[] values = GenericTester<ulong>.Values;

//            //  Максимально допустимое значение.
//            ulong maxValue = 10;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value > maxValue)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotLarger(value, maxValue, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotLarger(value, maxValue, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotLarger(value, maxValue, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotLarger(value, maxValue, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом sbyte.
//        {
//            //  Массив тестовых значений.
//            sbyte[] values = GenericTester<sbyte>.Values;

//            //  Максимально допустимое значение.
//            sbyte maxValue = 10;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value > maxValue)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotLarger(value, maxValue, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotLarger(value, maxValue, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotLarger(value, maxValue, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotLarger(value, maxValue, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом short.
//        {
//            //  Массив тестовых значений.
//            short[] values = GenericTester<short>.Values;

//            //  Максимально допустимое значение.
//            short maxValue = 10;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value > maxValue)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotLarger(value, maxValue, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotLarger(value, maxValue, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotLarger(value, maxValue, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotLarger(value, maxValue, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом int.
//        {
//            //  Массив тестовых значений.
//            int[] values = GenericTester<int>.Values;

//            //  Максимально допустимое значение.
//            int maxValue = 10;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value > maxValue)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotLarger(value, maxValue, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotLarger(value, maxValue, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotLarger(value, maxValue, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotLarger(value, maxValue, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом long.
//        {
//            //  Массив тестовых значений.
//            long[] values = GenericTester<long>.Values;

//            //  Максимально допустимое значение.
//            long maxValue = 10;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value > maxValue)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotLarger(value, maxValue, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotLarger(value, maxValue, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotLarger(value, maxValue, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotLarger(value, maxValue, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом float.
//        {
//            //  Массив тестовых значений.
//            float[] values = GenericTester<float>.Values;

//            //  Максимально допустимое значение.
//            float maxValue = 10;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value > maxValue)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotLarger(value, maxValue, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotLarger(value, maxValue, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotLarger(value, maxValue, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotLarger(value, maxValue, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом double.
//        {
//            //  Массив тестовых значений.
//            double[] values = GenericTester<double>.Values;

//            //  Максимально допустимое значение.
//            double maxValue = 10;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value > maxValue)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotLarger(value, maxValue, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotLarger(value, maxValue, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotLarger(value, maxValue, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotLarger(value, maxValue, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом decimal.
//        {
//            //  Массив тестовых значений.
//            decimal[] values = GenericTester<decimal>.Values;

//            //  Максимально допустимое значение.
//            decimal maxValue = 10;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value > maxValue)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotLarger(value, maxValue, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotLarger(value, maxValue, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotLarger(value, maxValue, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotLarger(value, maxValue, null));
//                }
//            }
//        }
//    }

//    /// <summary>
//    /// Тестирует методы проверки на равенство или превышение.
//    /// </summary>
//    [TestMethod]
//    public void TestIsLess()
//    {
//        //  Тестирование перегрузки с типом byte.
//        {
//            //  Массив тестовых значений.
//            byte[] values = GenericTester<byte>.Values;

//            //  Максимально допустимое значение.
//            byte maxValue = 10;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value >= maxValue)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsLess(value, maxValue, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsLess(value, maxValue, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsLess(value, maxValue, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsLess(value, maxValue, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом ushort.
//        {
//            //  Массив тестовых значений.
//            ushort[] values = GenericTester<ushort>.Values;

//            //  Максимально допустимое значение.
//            ushort maxValue = 10;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value >= maxValue)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsLess(value, maxValue, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsLess(value, maxValue, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsLess(value, maxValue, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsLess(value, maxValue, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом uint.
//        {
//            //  Массив тестовых значений.
//            uint[] values = GenericTester<uint>.Values;

//            //  Максимально допустимое значение.
//            uint maxValue = 10;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value >= maxValue)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsLess(value, maxValue, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsLess(value, maxValue, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsLess(value, maxValue, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsLess(value, maxValue, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом ulong.
//        {
//            //  Массив тестовых значений.
//            ulong[] values = GenericTester<ulong>.Values;

//            //  Максимально допустимое значение.
//            ulong maxValue = 10;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value >= maxValue)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsLess(value, maxValue, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsLess(value, maxValue, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsLess(value, maxValue, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsLess(value, maxValue, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом sbyte.
//        {
//            //  Массив тестовых значений.
//            sbyte[] values = GenericTester<sbyte>.Values;

//            //  Максимально допустимое значение.
//            sbyte maxValue = 10;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value >= maxValue)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsLess(value, maxValue, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsLess(value, maxValue, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsLess(value, maxValue, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsLess(value, maxValue, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом short.
//        {
//            //  Массив тестовых значений.
//            short[] values = GenericTester<short>.Values;

//            //  Максимально допустимое значение.
//            short maxValue = 10;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value >= maxValue)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsLess(value, maxValue, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsLess(value, maxValue, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsLess(value, maxValue, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsLess(value, maxValue, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом int.
//        {
//            //  Массив тестовых значений.
//            int[] values = GenericTester<int>.Values;

//            //  Максимально допустимое значение.
//            int maxValue = 10;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value >= maxValue)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsLess(value, maxValue, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsLess(value, maxValue, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsLess(value, maxValue, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsLess(value, maxValue, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом long.
//        {
//            //  Массив тестовых значений.
//            long[] values = GenericTester<long>.Values;

//            //  Максимально допустимое значение.
//            long maxValue = 10;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value >= maxValue)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsLess(value, maxValue, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsLess(value, maxValue, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsLess(value, maxValue, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsLess(value, maxValue, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом float.
//        {
//            //  Массив тестовых значений.
//            float[] values = GenericTester<float>.Values;

//            //  Максимально допустимое значение.
//            float maxValue = 10;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value >= maxValue)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsLess(value, maxValue, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsLess(value, maxValue, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsLess(value, maxValue, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsLess(value, maxValue, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом double.
//        {
//            //  Массив тестовых значений.
//            double[] values = GenericTester<double>.Values;

//            //  Максимально допустимое значение.
//            double maxValue = 10;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value >= maxValue)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsLess(value, maxValue, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsLess(value, maxValue, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsLess(value, maxValue, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsLess(value, maxValue, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом decimal.
//        {
//            //  Массив тестовых значений.
//            decimal[] values = GenericTester<decimal>.Values;

//            //  Максимально допустимое значение.
//            decimal maxValue = 10;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value >= maxValue)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsLess(value, maxValue, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsLess(value, maxValue, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsLess(value, maxValue, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsLess(value, maxValue, null));
//                }
//            }
//        }
//    }

//    /// <summary>
//    /// Тестирует методы проверки на недопустимо малое значение.
//    /// </summary>
//    [TestMethod]
//    public void TestLess()
//    {
//        //  Тестирование перегрузки с типом byte.
//        {
//            //  Массив тестовых значений.
//            byte[] values = GenericTester<byte>.Values;

//            //  Минимально допустимое значение.
//            byte minValue = 10;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value < minValue)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotLess(value, minValue, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotLess(value, minValue, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotLess(value, minValue, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotLess(value, minValue, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом ushort.
//        {
//            //  Массив тестовых значений.
//            ushort[] values = GenericTester<ushort>.Values;

//            //  Минимально допустимое значение.
//            ushort minValue = 10;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value < minValue)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotLess(value, minValue, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotLess(value, minValue, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotLess(value, minValue, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotLess(value, minValue, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом uint.
//        {
//            //  Массив тестовых значений.
//            uint[] values = GenericTester<uint>.Values;

//            //  Минимально допустимое значение.
//            uint minValue = 10;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value < minValue)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotLess(value, minValue, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotLess(value, minValue, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotLess(value, minValue, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotLess(value, minValue, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом ulong.
//        {
//            //  Массив тестовых значений.
//            ulong[] values = GenericTester<ulong>.Values;

//            //  Минимально допустимое значение.
//            ulong minValue = 10;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value < minValue)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotLess(value, minValue, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotLess(value, minValue, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotLess(value, minValue, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotLess(value, minValue, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом sbyte.
//        {
//            //  Массив тестовых значений.
//            sbyte[] values = GenericTester<sbyte>.Values;

//            //  Минимально допустимое значение.
//            sbyte minValue = 10;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value < minValue)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotLess(value, minValue, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotLess(value, minValue, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotLess(value, minValue, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotLess(value, minValue, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом short.
//        {
//            //  Массив тестовых значений.
//            short[] values = GenericTester<short>.Values;

//            //  Минимально допустимое значение.
//            short minValue = 10;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value < minValue)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotLess(value, minValue, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotLess(value, minValue, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotLess(value, minValue, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotLess(value, minValue, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом int.
//        {
//            //  Массив тестовых значений.
//            int[] values = GenericTester<int>.Values;

//            //  Минимально допустимое значение.
//            int minValue = 10;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value < minValue)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotLess(value, minValue, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotLess(value, minValue, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotLess(value, minValue, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotLess(value, minValue, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом long.
//        {
//            //  Массив тестовых значений.
//            long[] values = GenericTester<long>.Values;

//            //  Минимально допустимое значение.
//            long minValue = 10;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value < minValue)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotLess(value, minValue, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotLess(value, minValue, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotLess(value, minValue, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotLess(value, minValue, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом float.
//        {
//            //  Массив тестовых значений.
//            float[] values = GenericTester<float>.Values;

//            //  Минимально допустимое значение.
//            float minValue = 10;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value < minValue)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotLess(value, minValue, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotLess(value, minValue, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotLess(value, minValue, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotLess(value, minValue, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом double.
//        {
//            //  Массив тестовых значений.
//            double[] values = GenericTester<double>.Values;

//            //  Минимально допустимое значение.
//            double minValue = 10;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value < minValue)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotLess(value, minValue, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotLess(value, minValue, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotLess(value, minValue, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotLess(value, minValue, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом decimal.
//        {
//            //  Массив тестовых значений.
//            decimal[] values = GenericTester<decimal>.Values;

//            //  Минимально допустимое значение.
//            decimal minValue = 10;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value < minValue)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotLess(value, minValue, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsNotLess(value, minValue, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotLess(value, minValue, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsNotLess(value, minValue, null));
//                }
//            }
//        }
//    }

//    /// <summary>
//    /// Тестирует методы проверки на недопустимо малое значение.
//    /// </summary>
//    [TestMethod]
//    public void TestIsLarger()
//    {
//        //  Тестирование перегрузки с типом byte.
//        {
//            //  Массив тестовых значений.
//            byte[] values = GenericTester<byte>.Values;

//            //  Минимально допустимое значение.
//            byte minValue = 10;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value <= minValue)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsLarger(value, minValue, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsLarger(value, minValue, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsLarger(value, minValue, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsLarger(value, minValue, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом ushort.
//        {
//            //  Массив тестовых значений.
//            ushort[] values = GenericTester<ushort>.Values;

//            //  Минимально допустимое значение.
//            ushort minValue = 10;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value <= minValue)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsLarger(value, minValue, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsLarger(value, minValue, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsLarger(value, minValue, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsLarger(value, minValue, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом uint.
//        {
//            //  Массив тестовых значений.
//            uint[] values = GenericTester<uint>.Values;

//            //  Минимально допустимое значение.
//            uint minValue = 10;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value <= minValue)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsLarger(value, minValue, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsLarger(value, minValue, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsLarger(value, minValue, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsLarger(value, minValue, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом ulong.
//        {
//            //  Массив тестовых значений.
//            ulong[] values = GenericTester<ulong>.Values;

//            //  Минимально допустимое значение.
//            ulong minValue = 10;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value <= minValue)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsLarger(value, minValue, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsLarger(value, minValue, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsLarger(value, minValue, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsLarger(value, minValue, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом sbyte.
//        {
//            //  Массив тестовых значений.
//            sbyte[] values = GenericTester<sbyte>.Values;

//            //  Минимально допустимое значение.
//            sbyte minValue = 10;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value <= minValue)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsLarger(value, minValue, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsLarger(value, minValue, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsLarger(value, minValue, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsLarger(value, minValue, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом short.
//        {
//            //  Массив тестовых значений.
//            short[] values = GenericTester<short>.Values;

//            //  Минимально допустимое значение.
//            short minValue = 10;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value <= minValue)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsLarger(value, minValue, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsLarger(value, minValue, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsLarger(value, minValue, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsLarger(value, minValue, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом int.
//        {
//            //  Массив тестовых значений.
//            int[] values = GenericTester<int>.Values;

//            //  Минимально допустимое значение.
//            int minValue = 10;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value <= minValue)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsLarger(value, minValue, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsLarger(value, minValue, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsLarger(value, minValue, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsLarger(value, minValue, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом long.
//        {
//            //  Массив тестовых значений.
//            long[] values = GenericTester<long>.Values;

//            //  Минимально допустимое значение.
//            long minValue = 10;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value <= minValue)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsLarger(value, minValue, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsLarger(value, minValue, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsLarger(value, minValue, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsLarger(value, minValue, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом float.
//        {
//            //  Массив тестовых значений.
//            float[] values = GenericTester<float>.Values;

//            //  Минимально допустимое значение.
//            float minValue = 10;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value <= minValue)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsLarger(value, minValue, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsLarger(value, minValue, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsLarger(value, minValue, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsLarger(value, minValue, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом double.
//        {
//            //  Массив тестовых значений.
//            double[] values = GenericTester<double>.Values;

//            //  Минимально допустимое значение.
//            double minValue = 10;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value <= minValue)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsLarger(value, minValue, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsLarger(value, minValue, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsLarger(value, minValue, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsLarger(value, minValue, null));
//                }
//            }
//        }

//        //  Тестирование перегрузки с типом decimal.
//        {
//            //  Массив тестовых значений.
//            decimal[] values = GenericTester<decimal>.Values;

//            //  Минимально допустимое значение.
//            decimal minValue = 10;

//            //  Перебор тестовых значений.
//            foreach (var value in values)
//            {
//                //  Проверка значения.
//                if (value <= minValue)
//                {
//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsLarger(value, minValue, nameof(value)));

//                    //  Метод должен выбросить исключение.
//                    Assert.ThrowsException<ArgumentOutOfRangeException>(
//                        () => Check.IsLarger(value, minValue, null));
//                }
//                else
//                {
//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsLarger(value, minValue, nameof(value)));

//                    //  Метод должен вернуть проверяемое значение.
//                    Assert.AreEqual(value, Check.IsLarger(value, minValue, null));
//                }
//            }
//        }
//    }
//}
