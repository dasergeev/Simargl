﻿//using Apeiron.Templates;
//using Microsoft.VisualStudio.TestTools.UnitTesting;
//using System.Linq.Expressions;

//namespace UnitTest.Apeiron.Templates;

///// <summary>
///// Представляет тестовый класс для класса <see cref="Expressions"/>.
///// </summary>
//[TestClass]
//public class ExpressionsTest
//{
//    /// <summary>
//    /// Представляет тестовый статический метод.
//    /// </summary>
//    /// <param name="text">
//    /// Текстовая строка.
//    /// </param>
//    /// <param name="number">
//    /// Числовое значение.
//    /// </param>
//    /// <returns>
//    /// Возвращает сумму длины строки и числового значения.
//    /// </returns>
//    static int StaticMethod(string text, byte number)
//    {
//        //  Возврат суммы длины строки и числового значения.
//        return text.Length + number;
//    }

//    /// <summary>
//    /// Выполняет тестирование метода <see cref="Expressions.Call(Type, string, System.Linq.Expressions.Expression[])"/>.
//    /// </summary>
//    [TestMethod]
//    public void TestCall()
//    {
//        //  Создание текстового параметра.
//        ParameterExpression textParameter = Expression.Parameter(typeof(string));

//        //  Создание числового параметра.
//        ParameterExpression numberParameter = Expression.Parameter(typeof(byte));

//        //  Создание метода вызова.
//        MethodCallExpression methodCall = Expressions.Call(
//            typeof(ExpressionsTest), nameof(StaticMethod), textParameter, numberParameter);

//        //  Компиляция метода вызова.
//        Func<string, byte, int> methodLambda = Expression.Lambda<Func<string, byte, int>>(
//            methodCall, textParameter, numberParameter).Compile();

//        //  Вызов метода.
//        Assert.AreEqual(StaticMethod("text", 10), methodLambda("text", 10));
//    }
//}
