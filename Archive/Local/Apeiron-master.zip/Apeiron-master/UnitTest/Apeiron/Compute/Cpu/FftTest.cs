﻿using Apeiron.Compute.Cpu;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Numerics;
using System.Runtime.CompilerServices;

namespace UnitTest.Apeiron.Compute.Cpu;

/// <summary>
/// Представляет тестовый класс для класса <see cref="Fft"/>.
/// </summary>
[TestClass]
public class FftTest
{
    /// <summary>
    /// Постоянная, определяющая точность сравнения.
    /// </summary>
    const double _Epsilon = 0.000001;

    /// <summary>
    /// Постоянная, определяющая количество тестов.
    /// </summary>
    const int _Count = 128;

    /// <summary>
    /// Тестирует метод <see cref="Fft.Direct(Complex[])"/>.
    /// </summary>
    [TestMethod]
    public void DirectTest()
    {
        //  Создание инициализаторов.
        var initializers = CreateInitializers();

        //  Цикл по количеству тестов.
        for (int i = 0; i < _Count; i++)
        {
            //  Цикл по инициализаторам.
            foreach (var initializer in initializers)
            {
                //  Создание последовательности.
                Complex[] sequence = CreateSequence(i, initializer);

                //  Вычисление эталонного преобразования.
                var direct = DirectDft(sequence);

                //  Вычисление преобразования по алгоритму.
                Fft.Direct(sequence);

                //  Сравнение результатов.
                AreEquals(sequence, direct);
            }
        }
    }

    /// <summary>
    /// Тестирует метод <see cref="Fft.Inverse(Complex[])"/>.
    /// </summary>
    [TestMethod]
    public void InverseTest()
    {
        //  Создание инициализаторов.
        var initializers = CreateInitializers();

        //  Цикл по количеству тестов.
        for (int i = 0; i < _Count; i++)
        {
            //  Цикл по инициализаторам.
            foreach (var initializer in initializers)
            {
                //  Создание последовательности.
                Complex[] sequence = CreateSequence(i, initializer);

                //  Вычисление эталонного преобразования.
                var direct = InverseDft(sequence);

                //  Вычисление преобразования по алгоритму.
                Fft.Inverse(sequence);

                //  Сравнение результатов.
                AreEquals(sequence, direct);
            }
        }
    }

    /// <summary>
    /// Создаёт массив инициализаторов.
    /// </summary>
    /// <returns>
    /// Массив инициализаторов.
    /// </returns>
    static Func<int, Complex>[] CreateInitializers()
    {
        return new Func<int, Complex>[]
        {
            (int index) => new Complex(index, 0),
            (int index) => new Complex(0, index),
            (int index) => new Complex(index, index),
            (int index) => new Complex(index, Math.Cos(index)),
            (int index) => new Complex(index, Math.Sin(index)),
            (int index) => new Complex(Math.Cos(index), index),
            (int index) => new Complex(Math.Sin(index), index),
            (int index) => new Complex(Math.Cos(index), Math.Sin(index)),
            (int index) => new Complex(Math.Sin(index), Math.Cos(index)),
        };
    }

    /// <summary>
    /// Создаёт последовательность.
    /// </summary>
    /// <param name="length">
    /// Длина последовательности.
    /// </param>
    /// <param name="initializer">
    /// Инициализатор последовательности.
    /// </param>
    /// <returns>
    /// Новая последовательность.
    /// </returns>
    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    static Complex[] CreateSequence(int length, Func<int, Complex> initializer)
    {
        //  Создание массива.
        Complex[] sequence = new Complex[length];

        //  Заполнение массива.
        for (int i = 0; i < length; i++)
        {
            sequence[i] = initializer(i);
        }

        //  Возврат последовательности.
        return sequence;
    }

    /// <summary>
    /// Выполняет сравнение двух массивов.
    /// </summary>
    /// <param name="first">
    /// Первый массив.
    /// </param>
    /// <param name="second">
    /// Второй массив.
    /// </param>
    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    static void AreEquals(Complex[] first, Complex[] second)
    {
        //  Определение длины массивов.
        var length = first.Length;

        //  Цикл по всем элементам.
        for (int i = 0; i < length; i++)
        {
            //  Сравнение действительных частей.
            Assert.IsTrue(Math.Abs(first[i].Real - second[i].Real) < _Epsilon);

            //  Сравнение мнимых частей.
            Assert.IsTrue(Math.Abs(first[i].Imaginary - second[i].Imaginary) < _Epsilon);
        }
    }

    /// <summary>
    /// Выполняет прямое БПФ.
    /// </summary>
    /// <param name="sequence">
    /// Последовательность для преобразования.
    /// </param>
    /// <returns>
    /// Перобразованная последовательность.
    /// </returns>
    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    static Complex[] DirectDft(Complex[] sequence)
    {
        int length = sequence.Length;
        Complex[] result = new Complex[length];
        for (int k = 0; k < length; k++)
        {
            Complex value = 0;
            for (int m = 0; m < length; m++)
            {
                value += sequence[m] * Complex.Exp(-2 * Math.PI * Complex.ImaginaryOne * k * m / length);
            }
            result[k] += value;
        }
        return result;
    }

    /// <summary>
    /// Выполняет обратное БПФ.
    /// </summary>
    /// <param name="sequence">
    /// Последовательность для преобразования.
    /// </param>
    /// <returns>
    /// Перобразованная последовательность.
    /// </returns>
    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    static Complex[] InverseDft(Complex[] sequence)
    {
        int length = sequence.Length;
        Complex[] result = new Complex[length];
        for (int m = 0; m < length; m++)
        {
            Complex value = 0;
            for (int k = 0; k < length; k++)
            {
                value += sequence[k] * Complex.Exp(2 * Math.PI * Complex.ImaginaryOne * k * m / length);
            }
            result[m] += value / length;
        }
        return result;
    }
}
