﻿using Apeiron.IO;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Text;

namespace UnitTest.Apeiron.IO;

/// <summary>
/// Представляет тестовый класс для класса <see cref="PathBuilder"/>.
/// </summary>
[TestClass]
public sealed class PathBuilderTest
{
    /// <summary>
    /// Поле для хранения постоянной, определяющей количество выполняемых тестов.
    /// </summary>
    private const int _TestCount = 100;

    /// <summary>
    /// Поле для хранения массива разделителей каталогов, которые встречаются на всех платформах.
    /// </summary>
    private static readonly char[] _Separators = new char[] { '/', '\\' };

    /// <summary>
    /// Поле для хранения частей путей.
    /// </summary>
    private static readonly string[] _Parts =
    {
        "First", "Second", "Third"
    };

    /// <summary>
    /// Создаёт тестовое значение.
    /// </summary>
    /// <returns>
    /// Тестовое значение.
    /// </returns>
    private static string CreatePath()
    {
        //  Создание генератора случайных чисел.
        Random random = new(unchecked((int)(DateTime.Now.Ticks % int.MaxValue)));

        //  Количество составных частей.
        int count = 10 + (random.Next() % 20);

        //  Построитель строки.
        StringBuilder path = new();

        //  Добавление начального разделителя.
        if (random.Next() % 2 == 0)
        {
            path.Append(_Separators[random.Next() % _Separators.Length]);
        }

        //  Перебор частей.
        for (int i = 0; i < count; i++)
        {
            //  Добавление части.
            path.Append(_Parts[random.Next() % _Parts.Length]);

            //  Добавление разделителя.
            if (random.Next() % 2 == 0)
            {
                path.Append(_Separators[random.Next() % _Separators.Length]);
            }
        }

        //  Возврат полученной строки.
        return path.ToString();
    }

    /// <summary>
    /// Выполняет тестирование методов <see cref="PathBuilder.Combine(string, string)"/>
    /// и <see cref="PathBuilder.Combine(string[])"/>.
    /// </summary>
    [TestMethod]
    public void TestCombine()
    {
        //  Проверка передачи пустой ссылки.
        Assert.ThrowsException<ArgumentNullException>(() => PathBuilder.Combine(null!));
        Assert.ThrowsException<ArgumentNullException>(() => PathBuilder.Combine(null!, null!));
        Assert.ThrowsException<ArgumentNullException>(() => PathBuilder.Combine(null!, null!, null!));
        Assert.ThrowsException<ArgumentNullException>(() => PathBuilder.Combine(null!, CreatePath()));
        Assert.ThrowsException<ArgumentNullException>(() => PathBuilder.Combine(CreatePath(), null!));

        //  Проверка передачи пустой строки.
        Assert.ThrowsException<ArgumentOutOfRangeException>(() => PathBuilder.Combine(string.Empty));
        Assert.ThrowsException<ArgumentOutOfRangeException>(() => PathBuilder.Combine(string.Empty, string.Empty));
        Assert.ThrowsException<ArgumentOutOfRangeException>(() => PathBuilder.Combine(string.Empty, string.Empty, string.Empty));
        Assert.ThrowsException<ArgumentOutOfRangeException>(() => PathBuilder.Combine(string.Empty, CreatePath()));
        Assert.ThrowsException<ArgumentOutOfRangeException>(() => PathBuilder.Combine(CreatePath(), string.Empty));

        //  Передача пустого массива.
        Assert.ThrowsException<ArgumentOutOfRangeException>(() => PathBuilder.Combine(Array.Empty<string>()));

        //  Цикл по строкам.
        for (int i = 0; i < _TestCount; i++)
        {
            //  Создание путей.
            string[] paths = { CreatePath(), CreatePath(), CreatePath(), CreatePath(), CreatePath() };

            //  Цикл по количеству аругентов.
            for (int j = 0; j < paths.Length; j++)
            {
                //  Получение копии путей.
                string[] duplicate = (string[])paths.Clone();

                //  Обрезка путей.
                Array.Resize(ref duplicate, j + 1);

                //  Выполнение метода.
                string result = j switch
                {
                    0 => PathBuilder.Combine(duplicate[0]),
                    1 => PathBuilder.Combine(duplicate[0], duplicate[1]),
                    _ => PathBuilder.Combine(duplicate),
                };

                //  Нормализация первого пути.
                duplicate[0] = PathBuilder.Normalize(duplicate[0]);

                //  Нормализация последующих частей пути.
                for (int k = 1; k < duplicate.Length; k++)
                {
                    //  Нормализация части пути.
                    duplicate[k] = PathBuilder.RelativeNormalize(duplicate[k]);
                }

                //  Сравнение результатов.
                Assert.AreEqual(result, Path.Join(duplicate));
            }
        }
    }

    /// <summary>
    /// Выполняет тестирование метода <see cref="PathBuilder.RelativeNormalize"/>.
    /// </summary>
    [TestMethod]
    public void TestRelativeNormalize()
    {
        //  Проверка передачи пустой ссылки.
        Assert.ThrowsException<ArgumentNullException>(() => PathBuilder.RelativeNormalize(null!));

        //  Цикл по строкам.
        for (int i = 0; i < _TestCount; i++)
        {
            //  Создание пути.
            string path = CreatePath();

            //  Выполнение метода.
            string result = PathBuilder.RelativeNormalize(path);

            //  Нормализация нормализация пути с начальным разделителем.
            path = PathBuilder.NormalizeStartSeparator(path);

            //  Общая нормализация.
            path = PathBuilder.Normalize(path);

            //  Сравнение результатов.
            Assert.AreEqual(result, path);
        }
    }

    /// <summary>
    /// Выполняет тестирование метода <see cref="PathBuilder.Normalize"/>.
    /// </summary>
    [TestMethod]
    public void TestNormalize()
    {
        //  Проверка передачи пустой ссылки.
        Assert.ThrowsException<ArgumentNullException>(() => PathBuilder.Normalize(null!));

        //  Цикл по строкам.
        for (int i = 0; i < _TestCount; i++)
        {
            //  Создание пути.
            string path = CreatePath();

            //  Выполнение метода.
            string result = PathBuilder.Normalize(path);

            //  Нормализация пути с завершающим разделителем.
            path = PathBuilder.NormalizeEndSeparator(path);

            //  Нормализация разделителей каталогов.
            path = PathBuilder.NormalizeDirectorySeparators(path);

            //  Сравнение результатов.
            Assert.AreEqual(result, path);
        }
    }

    /// <summary>
    /// Выполняет тестирование метода <see cref="PathBuilder.NormalizeStartSeparator"/>.
    /// </summary>
    [TestMethod]
    public void TestNormalizeStartSeparator()
    {
        //  Проверка передачи пустой ссылки.
        Assert.ThrowsException<ArgumentNullException>(() => PathBuilder.NormalizeStartSeparator(null!));

        //  Цикл по строкам.
        for (int i = 0; i < _TestCount; i++)
        {
            //  Создание пути.
            string path = CreatePath();

            //  Выполнение метода.
            string result = PathBuilder.NormalizeStartSeparator(path);

            //  Нормализация пути.
            path = path.TrimStart(_Separators);

            //  Сравнение результатов.
            Assert.AreEqual(result, path);
        }
    }

    /// <summary>
    /// Выполняет тестирование метода <see cref="PathBuilder.NormalizeEndSeparator"/>.
    /// </summary>
    [TestMethod]
    public void TestNormalizeEndSeparator()
    {
        //  Проверка передачи пустой ссылки.
        Assert.ThrowsException<ArgumentNullException>(() => PathBuilder.NormalizeEndSeparator(null!));

        //  Цикл по строкам.
        for (int i = 0; i < _TestCount; i++)
        {
            //  Создание пути.
            string path = CreatePath();

            //  Выполнение метода.
            string result = PathBuilder.NormalizeEndSeparator(path);

            //  Нормализация пути.
            path = path.TrimEnd(_Separators);

            //  Сравнение результатов.
            Assert.AreEqual(result, path);
        }
    }

    /// <summary>
    /// Выполняет тестирование метода <see cref="PathBuilder.NormalizeDirectorySeparators"/>.
    /// </summary>
    [TestMethod]
    public void TestNormalizeDirectorySeparators()
    {
        //  Проверка передачи пустой ссылки.
        Assert.ThrowsException<ArgumentNullException>(() => PathBuilder.NormalizeDirectorySeparators(null!));

        //  Цикл по строкам.
        for (int i = 0; i < _TestCount; i++)
        {
            //  Создание пути.
            string path = CreatePath();

            //  Выполнение метода.
            string result = PathBuilder.NormalizeDirectorySeparators(path);

            //  Перебор всех разделителей.
            foreach (char separator in _Separators)
            {
                //  Замена разделителя.
                path = path.Replace(separator, Path.DirectorySeparatorChar);
            }

            //  Сравнение результатов.
            Assert.AreEqual(result, path);
        }
    }
}
