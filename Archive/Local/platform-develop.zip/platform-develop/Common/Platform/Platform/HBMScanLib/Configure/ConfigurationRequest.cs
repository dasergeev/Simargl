﻿// <copyright file="ConfigurationRequest.cs" company="Hottinger Baldwin Messtechnik GmbH">
//
// SharpScan, a library for scanning and configuring HBM devices.
//
// The MIT License (MIT)
//
// Copyright (C) Hottinger Baldwin Messtechnik GmbH
//
// Permission is hereby granted, free of charge, to any person obtaining
// a copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to
// permit persons to whom the Software is furnished to do so, subject to
// the following conditions:
//
// The above copyright notice and this permission notice shall be
// included in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
// NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
// BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
// ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
// CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
//
// </copyright>

namespace Hbm.Devices.Scan.Configure
{
    using System;
    using System.Runtime.Serialization;

    [DataContract]
    internal class ConfigurationRequest : JsonRpc
    {
        [DataMember(Name = "params")]
        private ConfigurationParams? _Parameters;

        internal ConfigurationRequest(ConfigurationParams parameters, string queryId) : this()
        {
            if (string.IsNullOrEmpty(queryId))
            {
                throw new ArgumentException(null, nameof(queryId));
            }

            QueryId = queryId;
            _Parameters = parameters ?? throw new ArgumentNullException(nameof(parameters));

            //  Для анализатора.
            _ = _Parameters;
        }

        private ConfigurationRequest()
        {
            Method = "configure";
        }

        [DataMember(Name = "id")]
        internal string QueryId { get; set; } = string.Empty;
    }
}
